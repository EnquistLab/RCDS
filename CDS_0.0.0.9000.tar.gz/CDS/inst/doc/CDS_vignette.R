## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## -----------------------------------------------------------------------------
library(CDS)

#First, we'll grab an example dataset containing two columns: latitude and longitude.
coordinates <- read.csv("https://bien.nceas.ucsb.edu/bien/wp-content/uploads/2020/10/cds_testfile.csv", stringsAsFactors = FALSE)

#Take a quick look at the input format
head(coordinates)

#Run the query
CDS_output <- CDS(coordinates = coordinates)

#Take a look at what is returned
tail(CDS_output,10)



## -----------------------------------------------------------------------------

#Information on political divisions coordinates fall within
tail(CDS_output[c("country","state","county")],n = 10)

#Information on absolute and relative distances (analagous columns for state and county levels)
tail(CDS_output[c("country_cent_dist","country_cent_dist_relative","country_cent_type","country_cent_dist_max","is_country_centroid")],10)

#Are the points likely centroids?
tail(CDS_output[c("is_country_centroid","is_state_centroid","is_county_centroid")],10)

#Are there any probems with the coordinates?
head(CDS_output["latlong_err"])


## -----------------------------------------------------------------------------

CDS_version()


